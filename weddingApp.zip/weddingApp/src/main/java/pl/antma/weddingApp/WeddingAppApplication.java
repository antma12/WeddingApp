package pl.antma.weddingApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WeddingAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(WeddingAppApplication.class, args);
	}

}
